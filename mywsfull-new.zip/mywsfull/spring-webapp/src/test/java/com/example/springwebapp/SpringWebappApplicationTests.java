package com.example.springwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
