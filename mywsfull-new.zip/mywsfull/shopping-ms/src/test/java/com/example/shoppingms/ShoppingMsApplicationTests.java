package com.example.shoppingms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
