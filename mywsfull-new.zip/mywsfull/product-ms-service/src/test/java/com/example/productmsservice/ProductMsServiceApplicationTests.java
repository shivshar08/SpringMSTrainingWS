package com.example.productmsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductMsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
